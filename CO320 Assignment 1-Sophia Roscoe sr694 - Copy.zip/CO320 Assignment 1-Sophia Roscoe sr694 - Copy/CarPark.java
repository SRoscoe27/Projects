
/**
 * This program is designed to simulate a program for managing 
 * car parks. This program will return the values for the car park's
 * maximum capasity and the number of cars currently within the car
 * park as well as the car parks location. The program will also
 * allow the user to change the maximum capasity of the car park
 * as well as the amount of cars currently within the car park and
 * the location of the car park. Finally the program will be able to 
 * print out a statement showing the current details of the car park
 *
 * This program was created by Sophia Roscoe (sr694)
 * Version 1
 */
//The main class CarPark is declared 
public class CarPark
{
    private String location; /** a private string variable called location is created to hold the location of the car park */
    private int capacity; /** A private variabe with the data type integer called capacity is created. This holds the number of spaces */
    private int occupancy; /** A private variable with the data type integer called occupancy is created. This shows the number of availiable spaces*/
/** Constructor called and demands two values a string value for name and integer for capnum*/
    public CarPark(String name, int capnum)
    {
        location = name;/**location is assigned the value of name*/
        capacity = capnum;/** capacity is assigned the value of capnum*/
        occupancy = 0;/**occupancy is always originally assigned the value of 0 */
    }
    /**Method to return the current capacity this method is named getCapasity and has the data type of a integer */
    public int getCapacity(){
        return capacity; /**returns the value of capasity to the user */

    }
    /**Method to return the current value for occupancy. This is called getOccupancy and has the data type of a integer*/
    public int getOccupancy(){
        return occupancy;/**returns the value of capacity to the user */
    }
    /**Method to return the current value for location. This is called getLocation and has the data type of a integer*/
    public String getLocation(){
        return location;/** returns the value of location to the user */
    }
    /**Method to deincriment the number of cars in the car park by 1*/
    public void leave(){
        if (occupancy>0 && occupancy<=capacity){ /** if occupancy is greater then 0 and occupancy is less then or equal to capacity */
            occupancy = occupancy-1; /**deincriment occupancy */
        }
        else{ /** if the above condition is not fufilled (if their are no cars)*/ 
            System.out.println("The car park is empty");/** print the statement */
        }
    }
    /**Method to incriment the number of cars in the car park by 1 */
    public void park(){
        if (occupancy<capacity && occupancy>=0){/**if occupancy is greater then capacity AND occupancy is greater or equal to 0 */
            occupancy = occupancy +1;/**increiment occupancy by 1*/
        }
        else{/**if the condition above is not fuffiled */
            System.out.println("The car park is full, please try again later");/**print statement*/
        }
    }
    /**Method to change the max capacity of the car park. The user enters the integer which is assigned to the variable change */ 
    public void changeCapacity(int change){
        if (capacity+change<occupancy){/**if capasity plus chage is less then occupancy*/
            System.out.println("Error - Car park capacity will be less then  the current occupancy please enter a lower number");
            /** print the cap capasity will be less then the current no of cars parked so an error occurs */
        }
        else if (capacity+change<=0 && occupancy==0){/**if the above condition is not fufilled but capasity+ change is less then or equal*/
            /**to 0 AND occupancy is equal to 0 perform the following*/
            capacity=0;/**assign capasity to 0*/
            System.out.println("The car park is now closed - Please leave");/**print out statement*/ 
        }
        else{/**if all conditions are not fuffilled*/
            capacity = capacity+change;/**capacity is assigned as capacity+change*/
        }   
    }
    /**Method to allow the user to change the location the user enters the new location into the varibale updlocation*/
    public void changeLocation(String updlocation){
        location=updlocation;/**Assign updlocation to location*/
    }
    /**Method to print the details of the location and the number of free spaces */
    public void printDetails(){
        System.out.println(location + " car park has " + (capacity-occupancy) + " spaces."); 
        /**calculate the number of new spaces and print the statement*/
    }
}
   