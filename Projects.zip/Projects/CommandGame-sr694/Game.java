import java.util.*;
/**
 *  This class is the central class of the "World of Home" application. 
 *  "World of Home" is a very simple, text based travel game.  Users 
 *  can walk around some house. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 * @author  Michael Kölling, David J. Barnes and Olaf Chitil
 * @author Sophia Roscoe (sr694)
 * @version 4/2/2019
 * 
 * @param currentRoom This is of type Room and holds the room the user is 
 * currently in 
 * @param finished a boolean to show if the game is finished or not
 * @param goal This is of type Room and contains the room that will finish
 * the game when it is the currentRoom. This is assigned to master.
 * @param count this contains the number of "go" commands the user performs
 *      Pre-condition this cannot be above 12
 * @param cookRoom this contains the value of kitchen and is the only room
 * the user can sucessfully cook in 
 * @param mother This is of type Character and is a character that resides
 * in the kitchen with the item sugar
 * @param father this is of type Character and is a character that resides
 * in the master bedroom, they do not have a item 
 * @param daughter This is of type Character and is a character that resides
 * in the garden and has the item flour
 * @param son This is of type Character and is a character that resides on
 * the stairs and has the item egg.
 * 
 * @param inventory This is an ArrayList which stores the items in the class 
 * Item when you take them from the currentRoom
 */

public class Game 
{
    private Room currentRoom;
    private boolean finished;
    private Room goal;
    private int count;
    private Room cookRoom;

    private Character mother;
    private Character father;
    private Character daughter;
    private Character son;
    ArrayList<Item> inventory = new ArrayList<>();
    /**
     * Create the game and initialise its internal map as well as the counter
     * for the go commands and the characters inside the rooms. These characters
     * are stored in the ArrayList Character.
     */
    public Game() 
    {
        finished = false;
        int count = 0;
        mother = new Character ("mother", Item.SUGAR);
        father = new Character ("father", null);
        daughter = new Character ("daugher", Item.FLOUR);
        son = new Character ("son", Item.EGG);

        createRooms();
    }

    /**
     * Create all the rooms and link their exits together. This also contains
     * two variables (goal and cookRoom) that are used to access designated
     * rooms.
     */
    private void createRooms()
    {
        Room front, hall, kitchen, livingroom, garden, cloakroom, stairs, bathroom, 
        master, ensuite, guest;

        // create the rooms
        front = new Room("in front of the house");
        hall = new Room("in the hallway");
        kitchen = new Room("in the kitchen");
        livingroom = new Room("in the livingroom");
        garden = new Room("in the garden");
        cloakroom = new Room("in the cloakroom");
        stairs = new Room("at the top of the stairs");
        bathroom = new Room("in the bathroom");
        master = new Room("in the master bedroom");
        ensuite = new Room("in the ensuite");
        guest = new Room("in the guest bedroom");
        goal=master;
        cookRoom = kitchen;

        // initialise room exits
        front.setExit(Direction.NORTH, hall);
        hall.setExit(Direction.SOUTH, front);
        hall.setExit(Direction.UP, stairs);
        hall.setExit(Direction.WEST, cloakroom);
        hall.setExit(Direction.EAST, kitchen);
        hall.setExit(Direction.NORTH, livingroom);
        kitchen.setExit(Direction.WEST, hall);
        kitchen.setExit(Direction.NORTH, livingroom);
        cloakroom.setExit(Direction.EAST, hall);
        livingroom.setExit(Direction.SOUTH, hall);
        livingroom.setExit(Direction.EAST, kitchen);
        livingroom.setExit(Direction.NORTH, garden);
        garden.setExit(Direction.SOUTH, livingroom);
        stairs.setExit(Direction.DOWN, hall);
        stairs.setExit(Direction.EAST, bathroom);
        stairs.setExit(Direction.SOUTH, guest);
        stairs.setExit(Direction.NORTH, master);
        bathroom.setExit(Direction.WEST, stairs);
        guest.setExit(Direction.NORTH, stairs);
        master.setExit(Direction.SOUTH, stairs);
        master.setExit(Direction.EAST, ensuite);
        ensuite.setExit(Direction.WEST, master);

        kitchen.addCharacter(mother);
        master.addCharacter(father);
        garden.addCharacter(daughter);
        stairs.addCharacter(son);

        currentRoom = front;  // start game at the front of the house
    }

    /**
     * Return the current room.
     * Post-condition: not null.
     */
    public Room getCurrent()
    {
        assert currentRoom != null : "Current room is null.";
        return currentRoom;
    }

    /**
     * Return whether the game has finished or not.
     */
    public boolean finished()
    {
        return finished;
    }

    /**
     * Opening message for the player.
     */
    public String welcome()
    {
        return "\nWelcome to the World of Home!\n" +
        "World of Home is a new game.\n" +
        currentRoom.getLongDescription() + "\n";
    }
    // implementations of user commands:
    /**
     * Give some help information.
     */
    public String help() 
    {
        return "You are lost. You are alone. You wander around the home.\n";
    }

    /** 
     * Try to go in one direction. If there is an exit, enter the new
     * room and return its long description; otherwise return an error message.
     * It also checks if the room you are in is the goal and if so prints out a 
     * appropreate congratuatory message and that the number of "go" commands
     * does not exceed 12. count is increased by 1 after each "go" command.
     * @param direction The direction in which to go.
     * @param nextRoom the current room with its avaliable exists
     * Pre-condition: direction is not null.
     * Pre-condition count is never greater than 12
     */
    public String goRoom(Direction direction) 
    {
        assert direction != null : "Game.goRoom gets null direction";
        // Try to leave current room.
        Room nextRoom = currentRoom.getExit(direction);
        if (count<11){
            
            if (nextRoom == null) {
                return "There is no exit in that direction!";
            }

            else if (currentRoom.equals(goal)){
                quit();
                return getCurrent().getLongDescription() + "\nCongratulations! You reached the goal.\nThank you for playing.  Good bye.";
            }

            else {
                currentRoom = nextRoom;
                count++;
                return currentRoom.getLongDescription();
            }

        }
        else{
            quit();
            return getCurrent().getLongDescription() + "\nLost! You ran out of time.\nThank you for playing.  Good bye.";
        }

    }

    /**
     * Execute quit command. This ends the game and outputs a message
     */
    public String quit()
    {
        finished = true;
        return "Thank you for playing.  Good bye.";
    }

    /**
     * Execute look command. This allows the user to view their current room and
     * all exists from a room with a "look" command
     */
    public String look()
    {
        StringBuilder result = new StringBuilder();
        result.append(currentRoom.getLongDescription());
        return result.toString(); 
    }

    /**
     * Execute take command.
     * @param item The item to take. Here the item if found is added to the 
     * ArrayList inventory
     * Pre-condition: item is not null.
     */
    public String take(Item item)
    {
        assert item != null : "Game.take item is null";
        if (currentRoom.take(item)){
            inventory.add(item);
            return "Item taken.";
        }
        else{
            return "Item not in this room.";
        }

    }

    /**
     * Execute cook command. Here if the user has all 3 items in their ArrayList
     * of inventory and currentRoom is equal to kitchen (cookRoom) the game ends
     * and a message is printed.
     */
    public String cook()
    {
        if(currentRoom.equals(cookRoom)){

            if (inventory.contains(Item.FLOUR)) 
            {

                if (inventory.contains(Item.SUGAR)){

                    if(inventory.contains(Item.EGG)){
                        return "Congratulations! You have won.\nThank you for playing.  Good bye.";
                    }

                    else{
                        return "You cannot cook yet.";
                    }

                }
                else{
                    return "You cannot cook yet.";
                }

            }
            else{
                return "You cannot cook yet."; 
            }

        }
        else{
            return "You cannot cook yet.";
        }
    }
}
