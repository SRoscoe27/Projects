
/**
 * Enumeration class Character
 * A character in the game.
 * 
 * @author Olaf Chitil
 * @author Sophia Roscoe (sr694)
 * @version 4/2/2019
 * 
 * @param description This contaisn the description of the character
 * @param it this is of type item and holds the item the user contains (if it does)
 * @param takeItem This shows if the item has been taken from the user
 * (0 means false and 1 means true)
 */
public class Character
{
    private String description;
    public Item it;
    public int takeItem;
    /**
     * Constructor initialising description and item and takeItem.
     * If it is equal to null then take item is intitulised as 0 else it is set
     * to 1.
     */
    public Character(String description, Item it)
    {
        this.description = description;
        this.it=it;
        if(it == null)
        {
            takeItem=0;
        }else{
            takeItem = 1;
        }
    }

    /*
     * Return the description and description of item if it exists.
     */
    public String toString()
    {
        if (it == null){
            return description;
        }
        else{
            return description + " having the item " + it.toString();
        }
    }

    /**
     * Take the given item from the character if it has that item.
     * Return whether item was taken.
     * If the item inputted by the user is the same as it and takeItem is less
     * than 1 then item is taken and returns true else it returns false
     */
    public boolean take(Item item)
    {
        if(it==item  && takeItem<1){
            takeItem=0;
            return true;
        }else{
            return false;
        }
    }
}
