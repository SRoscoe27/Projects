
/**
 * Enumeration class Item
 * The items in the game. These are converted into strings and outputted using 
 * toString()
 * 
 * @author Olaf Chitil
 * @author Sophia Roscoe (sr694)
 * @version 4/2/2019
 * 
 * @param commandString this holds the parameterised enums so they can be accessed
 * and added to other classes/variables
 */
public enum Item
{
    FLOUR("flour"), 

    SUGAR("sugar"), 

    EGG("egg");
    
    private String commandString;
    
    /**
     * Initulises commandString
     */
    Item(String commandString){
        this.commandString=commandString;
    
    }
    
    /**
     * Return the description of the item.
     */
    public String toString()
    {
        return commandString; 
    }
}
