<?php
$data = $_GET['sid'];
   // Connect to database, and print error message if it fails
   try {
      $dbhandle = new PDO('mysql:host=dragon.kent.ac.uk; dbname=co323',
                          'co323', 'pa33word');
   } 
   catch (PDOException $e) {
      // The PDO constructor throws an exception if it fails
      die('Error Connecting to Database: ' . $e->getMessage());
   }
   
   // Run the SQL queries, and print error messages if they fail.
   $sql1 = "SELECT DISTINCT s.sid, a.cid, c.title, a.name, a.weighting, g.mark, SUM(g.mark*a.weighting)/(SUM(a.weighting)) FROM (Course c JOIN Assessment a ON c.cid=a.cid JOIN Grade g ON a.aid=g.aid JOIN Student s ON s.sid=g.sid)WHERE s.sid='$data' GROUP BY cid,name ORDER BY cid;";
   $sql2 = "SELECT DISTINCT s.sid, a.cid, c.title, SUM(g.mark*a.weighting)/(SUM(a.weighting))FROM (Course c JOIN Assessment a ON c.cid=a.cid JOIN Grade g ON a.aid=g.aid JOIN Student s ON s.sid=g.sid) WHERE s.sid='$data' GROUP BY cid ORDER BY cid";
   $query1 = $dbhandle->prepare($sql1);
   $query2 = $dbhandle->prepare($sql2);

   // Parameterized queries are used to ensure that the sid collected
   // from task 6 is the same as the sid of the information retrieved 
   // from the query ensuring the information is correct.
   
   if ( $query1->execute(array('sid' => $data)) == FALSE ) {
      die('Error Running Query: ' . implode($query1->errorInfo(),' ')); 
   } 
   if ( $query2->execute(array('sid' => $data)) == FALSE ) {
      die('Error Running Query: ' . implode($query2->errorInfo(),' ')); 
   }
		
   // Put the results into associative arrays
   $results1 = $query1->fetchAll();
   $results2 = $query2->fetchAll();
?>

<!-- Here the student id of the user the user clicked on is searched
and the result from the first query (sq11) is outputted to the user.  -->

	<u>Results for Student ID <?php echo $data ?></u> <br><br>
<?php	
   // Printing out the course details in the array results
   foreach ($results1 as $row){
	   echo $row['cid']." | ".$row['title']." | ".$row['name']." | ".$row['mark']."<br>";
	   
   }
   
?>
<p></p>

<!-- Here the student id of the user the user clicked on is searched
and the result from the second query (sq12) is outputted to the user.
This leads to the final results of the user clicked being outputted
to the user  -->

<u>Final Mark for Student <?php echo $data ?></u><br><br>
<?php
   foreach ($results2 as $row){
	   
	   echo $row['title']." | ".$row['SUM(g.mark*a.weighting)/(SUM(a.weighting))']."<br>"; 
	   
   }

?>



