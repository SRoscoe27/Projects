import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
/**
 * Write a description of class GameV4 here.
 *
 * @author Sophia Roscoe
 * @version Version 4 09/03/19
 * 
 * @param count - the number of buttons clicked. This is of type integer
 * @param win - The number of clicked needed to win. This is set to 5 (easy) but
 * can be changed using buttons. This is of type integer
 * @param bomb - A random number inbetween 0 and 9. This is on type double
 * but its value is casted as a integer
 * @param playing - This boolean value is set to false and is true when the user
 * begins the game 
 * @param frame - The main frame for the program 
 * @param grids - This is an ArrayList of type JButton which contain all the buttons
 */
public class GameV4
{
    private int count = 0;
    private int win = 5;
    private double bomb;
    private boolean playing = false;
    private JFrame frame = new JFrame("Chasing Bomb Game");
    private ArrayList<JButton> grids = new ArrayList<JButton>();

    /**
     * Performs the function makeFrame
     */
    public GameV4()
    {
        makeFrame();
    }

    /**
     * This function makes all the panels and accessories attached to it.
     * This also contains the functions for each of the buttons
     * 
     * @param text - This is a JLabel which in the beginning is a blank text 
     * label but can be set diffrent values depending on whether the user wins
     * or loses.
     * @param play - a JButton which when clicked begins the game. This is added
     * to the middle panel (playp)
     * @param exit - A JButton which when clicked caused the screen to close.
     * This is added to the middle panel (playp)
     * @param easy - A JRadioButton which when selected makes the value of win
     * equal to 5. Meaning that the user must click 5 non-bomb buttons to win
     * @param medium - A JRadioButton which when selected makes the value of win
     * equal to 7. Meaning that the user must click 7 non-bomb buttons to win
     * @param win - A JRadioButton which when selected makes the value of win
     * equal to 1. Meaning that the user loses no matter what button they click.
     * @param mainFrame - AJPanel. The main panel what contais the other panels.
     * @param gridp - A JPanel. This is the panel that along with the buttons
     * creates the grid for the game.
     * @param button. This is a JButton and creates a button within a range between
     * 0 to 9. This overall creates the main part of the game.
     * @param diffp - This creates the right panel. This is set to blue and hold 
     * the buttons that set the difficulty.
     * 
     * Pre-Condition - the bomb must be inbetween 0-9
     * Post-Condition - If the value of win is equal to 1 than the bomb
     * is set the value of the button just clicked
     * Post-Condition - if the value of the bomb is equal to the index of the 
     * button than the game is over and the count is reset to 0 and all
     * buttons are re-enabled.
     * Post-Condition - If the variable count is the same or more than the 
     * variable win then the game is over in victory and the count and buttons
     * are reset.
     * Post-Condition - if the button easy is selected when win is equal to 5
     * and the other two buttons are disabled
     * Post-Condition - if the button medium is selected when win is equal to 7
     * and the other two buttons are disabled
     * Post-Condition - if the button hard is selected when win is equal to 1
     * and the other two buttons are disabled
     * 
     */
    public void makeFrame(){
        //sets basic dimentions of the frame
        frame.setSize(900,600);
        frame.setMinimumSize(new Dimension(900,600));
        frame.setLayout(new BorderLayout(8,8));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        //creates buttons that assign difficulty and 
        JLabel text = new JLabel("");
        JButton play = new JButton("Play A Game");
        JRadioButton easy = new JRadioButton("Difficulty - Easy");
        JRadioButton medium = new JRadioButton("Difficulty - Intermediate");
        JRadioButton hard = new JRadioButton("Difficulty - Hard");
        easy.setSelected(true);

        //creates main frame/panel
        //Container mainFrame=frame.getContentPane();
        JPanel mainFrame = (JPanel)frame.getContentPane();
        mainFrame.setBackground(Color.WHITE);
        mainFrame.setVisible(true);

        //Creates the left panel with all accessories attached to it. This 
        //includes the grid of buttons. The functionally of the buttons 
        //when clicked is also produced here.

        JPanel gridp = new JPanel(); 
        gridp.setLayout(new GridLayout(2,5,3,3));
        gridp.setPreferredSize(new Dimension(300,600));
        for (int i = 0; i<10; i++){
            JButton button = new JButton("");
            button.setBackground(Color.RED);
            gridp.add(button);
            grids.add(button);
            button.addActionListener(e ->{

                    if (playing){
                        button.setEnabled(false);
                        if (hard.isSelected()){
                            bomb = grids.indexOf(button);
                        }
                        if (grids.indexOf(button)==(bomb)){
                            button.setBackground(Color.BLACK);
                            easy.setEnabled(true);
                            medium.setEnabled(true);
                            hard.setEnabled(true);
                            play.setEnabled(true);
                            text.setText("You Lose! You got " + count + " point(s) ");
                            playing = false;
                        }
                        else{
                            button.setBackground(Color.YELLOW);
                            count++;
                        }

                        if (count>=win){
                            text.setText("You've Won, Congrats!");
                            easy.setEnabled(true);
                            medium.setEnabled(true);
                            hard.setEnabled(true);
                            play.setEnabled(true);
                            count = 0;
                            playing = false;
                        }
                    }

                });
        }    

        //sets middle panel for play buttons and their layout
        JPanel playp = new JPanel();
        playp.setBackground(Color.GREEN);
        playp.setLayout(new BoxLayout(playp, BoxLayout.Y_AXIS));
        playp.setPreferredSize(new Dimension(300,600));

        // the exit button is created and this plus the play button are added
        //to the middle pane 
        JButton exit = new JButton("Exit");
        
        playp.add(Box.createVerticalStrut(20));
        playp.add(play);
        play.setAlignmentX(Component.CENTER_ALIGNMENT);
        playp.add(Box.createVerticalStrut(20));
        
        playp.add(exit);  
        exit.setAlignmentX(Component.CENTER_ALIGNMENT);
        playp.add(Box.createVerticalStrut(20));
        
        text.setAlignmentX(Component.CENTER_ALIGNMENT);
        playp.add(Box.createVerticalStrut(20));
        
        playp.add(text, BorderLayout.CENTER);
        playp.add(Box.createHorizontalStrut(30));

        //The right panel is created and all accessories attached to it are created 
        //and added to the panel
        JPanel diffp = new JPanel();
        diffp.setBackground(Color.BLUE);
        diffp.setPreferredSize(new Dimension(300,600));
        diffp.setLayout(new BoxLayout(diffp,BoxLayout.Y_AXIS));
        
        diffp.add(Box.createVerticalStrut(20));
        diffp.add(easy);
        easy.setAlignmentX(Component.CENTER_ALIGNMENT);
        diffp.add(Box.createVerticalStrut(20));

        diffp.add(medium);
        medium.setAlignmentX(Component.CENTER_ALIGNMENT);
        diffp.add(Box.createVerticalStrut(20));

        diffp.add(hard);
        hard.setAlignmentX(Component.CENTER_ALIGNMENT);
        diffp.add(Box.createVerticalStrut(20));

        //add all panels to mainFrame
        mainFrame.add(gridp,BorderLayout.WEST);
        mainFrame.add(playp,BorderLayout.CENTER);
        mainFrame.add(diffp,BorderLayout.EAST);
        mainFrame.setVisible(true);
        
        //The functionallity of the play button. If the variable playing
        //is false then all buttons are made unaccessable and playing is set to 
        //true. The game then begins.

        play.addActionListener(e ->{
                if(!playing){
                    easy.setEnabled(false);
                    medium.setEnabled(false);
                    hard.setEnabled(false);
                    play.setEnabled(false);
                    playing = true;
                    count = 0;
                    text.setText("Game Started. BEGIN!");
                    bomb = (int)Math.round(Math.random()*9);
                    for(JButton b : grids){
                        b.setEnabled(true);
                        b.setBackground(Color.RED);
                    }

                }
            });

        // This makes it so when clicked the window is closed
        exit.addActionListener(e -> {
                frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
            });

        // When easy is clicked the variable win contains the value 5 and the other two 
        // two buttons are disabled.
        easy.addActionListener(e ->{
                if (easy.isSelected()){
                    //easy.setBackground(Color.YELLOW);
                    win = 5;
                    medium.setSelected(false);
                    hard.setSelected(false);
                }
            });

        // When medium is clicked the variable win contains the value 7 and the other two 
        // two buttons are disabled.
        medium.addActionListener(e ->{
                if (medium.isSelected()){
                    //medium.setBackground(Color.YELLOW);
                    win = 7;
                    easy.setSelected(false);
                    hard.setSelected(false);
                }
            });

        // When hard is clicked the variable win contains the value 1 and the other two 
        // two buttons are disabled.
        hard.addActionListener(e ->{
                if (hard.isSelected()){
                    //hard.setBackground(Color.YELLOW);
                    //win = 1;
                    easy.setSelected(false);
                    medium.setSelected(false);
                }
            });
        frame.pack();
        mainFrame.setVisible(true);
        
    }
}
