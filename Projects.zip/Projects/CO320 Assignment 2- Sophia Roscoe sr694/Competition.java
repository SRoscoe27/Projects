/**
 * This class performs a vareity of functions including adding a user to a
 * array of type personality and allowing a user to see these members name,sport and 
 * the number of votes they have individually or all listed in a set format.
 * The user is also able to increment the votes of a member of the arrayList
 * Furthermore the user is able to remove members that are below a certain vote which they decide
 * Finally the user can input a value and the program will return the top highest votes
 * within the range of 0 and the value the user entered.
 * 
 * @Author Sophia Roscoe
 * @Version 1.3 (Final Version)
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;
import java.util.Iterator;

public class Competition
{
    private ArrayList<Personality> members;
    /**
     * Constructor for objects of class PersonalityList. Here a new arrayList
     * called members is created. This will hold the objects in Personality
     */
    public Competition()
    {
        members = new ArrayList<>();
    }

    /**
     * An Accessor method that when decleared allows the user to add a member to 
     * the arrayList members. The user enters the new members' name (@name) and 
     * sport (@sport) and these are added to the ArrayList members with the structure of the Personality
     * class
     * @param member contains @name and @sport
     */
  
    public void addPersonality(Personality member)
    {
        members.add(member);
    }

    /**
     * An Accessor method which when declared returns the size and thus number
     * of members (people) in the ArrayList
     */
    
    public int getSize()
    {
        return members.size();
    }

    /**
     * A mutator method that outputs all the details of members in the ArrayList
     * members using the getDetails method (see the Personality class)
     */
    
    public void list()
    {

        for (Personality item :members){
            System.out.println(item.getDetails());
        }

    }

    /**
     * A mutator method that allows the user to increment the votes
     * a member of their choosing by one 
     * @param name the users name they wish to increase the votes of
     * This uses the method .increaseVotes (see Personality)
     * User must exist inside the system
     */
    
    public void voteFor(String name)
    {
        boolean searching = true;
        for (Personality item:members){
            String a = item.getName();
            if (a.equals(name)){
                item.increaseVotes(1);
                System.out.println("Vote Successful");
                searching = false;
            }

        }

        if (searching== true){
            System.out.println("Error - User not found");
        } 

    }

    /**
     * a Mutator method that removes any member from the list whos votes are less
     * then the integer the user entered
     * @param minimumVotes the value that members votes must be above else they are 
     * removed from the ArrayList
     */
    
    public void shortlist(int minimumVotes)
    { 
        Iterator<Personality> it = members.iterator();
        while (it.hasNext()){
            Personality nextItem = it.next();
            if (nextItem.getVotes() < minimumVotes){
                it.remove();
            }

        }

    }

    /**
     * Returns the highest votes within the members ArrayList between
     * the range of 0 less then the quantity (quantity-1). This is done 
     * by using the Collections and Comparator packages along with reverse to
     * sort the members list by votes using .getVotes (see Personality) and 
     * then the votes in the given range are placed in a seperate ArrayList
     * called topVotes and are returned.
     * @param quantity the number of votes outputted.
     * The quanity must be greater then 0 else a error message appears
     * if the quanity is greater then the size of the members ArrayList
     * then the full members ArrayList is outputted
     */
    
    public ArrayList<Personality> getMost(int quantity)
    {

        Collections.sort(members, Comparator.comparing(Personality::getVotes));
        Collections.reverse(members);
        ArrayList<Personality> topVotes = new ArrayList<>();
        boolean searching = true;

        if (quantity>=members.size()){
            return members;
        }

        else if (quantity <= 0 || quantity == 00){
            System.out.println("Incorrect range");
            return topVotes;
        }

        else{

            for (int i=0; i<quantity; i++){
                topVotes.add(members.get(i));
            }
            int value = quantity-1;
            while (searching==true && value<members.size()){

                try{

                    if (members.get(value).getVotes() == members.get(value+1).getVotes()){
                        topVotes.add(members.get(value+1));
                        value++;   
                    }

                    else{
                        searching=false;
                    }

                }

                catch (Exception e){
                    break;
                }

            }
            return topVotes;
        }
    }
}

