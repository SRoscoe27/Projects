<?php
   // Connect to database, and print error message if it fails
   try {
      $dbhandle = new PDO('mysql:host=dragon.kent.ac.uk; dbname=co323',
                          'co323', 'pa33word');
   } 
   catch (PDOException $e) {
      // The PDO constructor throws an exception if it fails
      die('Error Connecting to Database: ' . $e->getMessage());
   }
   
   // Run the SQL query, and print error message if it fails.
   $idsql = "SELECT * FROM Student";	
   $idquery = $dbhandle->prepare($idsql);
   
   if ( $idquery->execute() === FALSE ) {
      die('Error Running Query: ' . implode($query->errorInfo(),' ')); 
   }
		
   // Put the results into a nice big associative array
   $results = $idquery->fetchAll();
	
   // Printing out the course details in the array results
?>

<!-- A drop down menu is created containing all the data retrieved--
by the SQL query. The user then clicks one of them and presses the 
button "Find Student". This when clicked transfers the user to task7.php
and transfers the information in the form to the next task.
-->
   <h2>Task 3</h2>
<form action="task7.php" method ="GET">
	Student Name and Gender:<br><select type="SelectStu" value="SelectStu" name="sid">
	<option disabled selected> Click to view all Student Names and Genders </option>
<?php
	foreach($results as $row){
		echo "<option value = ".$row['sid'].">".$row['forename']." ".$row['surname']." ".$row['gender']."</option>";
		
	}
?>		
</select>
	<input type = "submit" value="Find Student"/>
</form>