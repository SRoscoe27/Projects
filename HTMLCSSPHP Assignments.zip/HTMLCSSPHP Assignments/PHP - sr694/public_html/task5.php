<style> 
	td, tr, th, table{border:solid 1px;font-family: Veranda;}
		table{border-collapse:collapse}
</style>

<?php
   // Connect to database, and print error message if it fails
   try {
      $dbhandle = new PDO('mysql:host=dragon.kent.ac.uk; dbname=co323',
                          'co323', 'pa33word');
   } 
   catch (PDOException $e) {
      // The PDO constructor throws an exception if it fails
      die('Error Connecting to Database: ' . $e->getMessage());
   }
   
   // Run the SQL query, and print error message if it fails.
   $sql = "SELECT DISTINCT a.cid, a.name, AVG(g.mark) FROM (Assessment a JOIN Grade g ON a.aid=g.aid) GROUP by cid,name ORDER BY cid,name";
   $query = $dbhandle->prepare($sql);

   if ( $query->execute() === FALSE ) {
      die('Error Running Query: ' . implode($query->errorInfo(),' ')); 
   }
?>

<!-- details retrieved using the SQL query are outputted in a HTML table 
This data includes the CID, name and average mark achieved. 
 -->

   <h2>Details of Task 2</h2>
<table>
	<tr><th> CID </th><th> Name </th><th> Average Mark </th>
<?php while ($row = $query-> fetch()){ ?>
	<tr>
		<td><?php echo $row['cid']; ?></td>
		<td><?php echo $row['name']; ?></td>
		<td><?php echo $row['AVG(g.mark)']; ?></td>
	</tr>
	<?php }?>
</table>